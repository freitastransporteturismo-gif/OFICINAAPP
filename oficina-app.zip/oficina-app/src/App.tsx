import { Navigate, Route, Routes } from "react-router-dom";
import { useSession } from "./hooks/useSession";
import LoginPage from "./pages/LoginPage";
import ClientsPage from "./pages/ClientsPage";
import ClientDetailPage from "./pages/ClientDetailPage";
import ServiceOrderPage from "./pages/ServiceOrderPage";

export default function App() {
  const { session, loading } = useSession();

  if (loading) return null;

  if (!session) {
    return (
      <Routes>
        <Route path="*" element={<LoginPage />} />
      </Routes>
    );
  }

  return (
    <Routes>
      <Route path="/" element={<ClientsPage />} />
      <Route path="/clientes/:id" element={<ClientDetailPage />} />
      <Route path="/ordens/:id" element={<ServiceOrderPage />} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
