import { createClient } from "@supabase/supabase-js";

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface Client {
  id: string;
  name: string;
  phone: string;
  created_at: string;
}

export interface Vehicle {
  id: string;
  client_id: string;
  brand: string;
  model: string;
  year: string | null;
  plate: string | null;
}

export type OrderStatus =
  | "aberta"
  | "em_andamento"
  | "aguardando_aprovacao"
  | "aprovado"
  | "concluido";

export interface ServiceOrder {
  id: string;
  client_id: string;
  vehicle_id: string;
  description: string;
  status: OrderStatus;
  created_at: string;
}

export interface ServiceItem {
  id: string;
  service_order_id: string;
  description: string;
  value: number;
}

export interface ServicePhoto {
  id: string;
  service_order_id: string;
  url: string;
  phase: "antes" | "depois";
}
