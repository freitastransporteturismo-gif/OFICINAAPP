import { Client, ServiceItem, Vehicle } from "./supabase";

export function buildBudgetWhatsAppLink({
  client,
  vehicle,
  items,
}: {
  client: Client;
  vehicle: Vehicle;
  items: ServiceItem[];
}) {
  const total = items.reduce((sum, i) => sum + Number(i.value), 0);

  const lines = [
    `Olá, ${client.name}! Segue o orçamento do seu ${vehicle.brand} ${vehicle.model}${vehicle.plate ? ` (placa ${vehicle.plate})` : ""}:`,
    "",
    ...items.map(
      (i) => `• ${i.description} — R$ ${Number(i.value).toFixed(2)}`,
    ),
    "",
    `Total: R$ ${total.toFixed(2)}`,
    "",
    "Qualquer dúvida, é só chamar por aqui!",
  ];

  const message = lines.join("\n");
  const encoded = encodeURIComponent(message);
  return `https://wa.me/${client.phone}?text=${encoded}`;
}
