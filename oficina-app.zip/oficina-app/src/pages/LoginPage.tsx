import { useState } from "react";
import { supabase } from "../lib/supabase";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    setLoading(false);
    if (error) setError("E-mail ou senha incorretos.");
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-canvas px-5">
      <form
        onSubmit={handleLogin}
        className="w-full max-w-sm border border-line bg-surface p-6"
      >
        <p className="text-sm text-accent">🔧 Oficina</p>
        <h1 className="mb-6 font-display text-2xl font-semibold uppercase tracking-tight">
          Entrar
        </h1>

        <div className="mb-4">
          <label className="mb-1 block text-sm font-medium">E-mail</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full border border-line bg-surface px-3 py-2 text-sm outline-none focus:border-accent"
            required
          />
        </div>

        <div className="mb-4">
          <label className="mb-1 block text-sm font-medium">Senha</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full border border-line bg-surface px-3 py-2 text-sm outline-none focus:border-accent"
            required
          />
        </div>

        {error && <p className="mb-4 text-sm text-cancel">{error}</p>}

        <button
          type="submit"
          disabled={loading}
          className="w-full bg-ink py-3 font-medium text-canvas disabled:opacity-40"
        >
          {loading ? "Entrando…" : "Entrar"}
        </button>
      </form>
    </div>
  );
}
