import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { AppShell } from "../components/AppShell";
import { supabase, Client, Vehicle, ServiceOrder } from "../lib/supabase";

const statusLabel: Record<ServiceOrder["status"], string> = {
  aberta: "Aberta",
  em_andamento: "Em andamento",
  aguardando_aprovacao: "Aguardando aprovação",
  aprovado: "Aprovado",
  concluido: "Concluído",
};

export default function ClientDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [client, setClient] = useState<Client | null>(null);
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [orders, setOrders] = useState<ServiceOrder[]>([]);

  const [showVehicleForm, setShowVehicleForm] = useState(false);
  const [brand, setBrand] = useState("");
  const [model, setModel] = useState("");
  const [year, setYear] = useState("");
  const [plate, setPlate] = useState("");

  useEffect(() => {
    if (id) load();
  }, [id]);

  async function load() {
    const [{ data: c }, { data: v }, { data: o }] = await Promise.all([
      supabase.from("clients").select("*").eq("id", id).single(),
      supabase.from("vehicles").select("*").eq("client_id", id),
      supabase
        .from("service_orders")
        .select("*")
        .eq("client_id", id)
        .order("created_at", { ascending: false }),
    ]);
    setClient(c as Client);
    setVehicles((v as Vehicle[]) ?? []);
    setOrders((o as ServiceOrder[]) ?? []);
  }

  async function handleAddVehicle(e: React.FormEvent) {
    e.preventDefault();
    await supabase
      .from("vehicles")
      .insert({ client_id: id, brand, model, year, plate });
    setBrand("");
    setModel("");
    setYear("");
    setPlate("");
    setShowVehicleForm(false);
    load();
  }

  async function handleNewOrder(vehicleId: string) {
    const { data } = await supabase
      .from("service_orders")
      .insert({ client_id: id, vehicle_id: vehicleId })
      .select()
      .single();
    if (data) navigate(`/ordens/${data.id}`);
  }

  if (!client) return null;

  return (
    <AppShell>
      <Link to="/" className="mb-4 inline-block text-sm text-muted hover:text-ink">
        ← Todos os clientes
      </Link>

      <h2 className="font-display text-2xl font-semibold uppercase tracking-tight">
        {client.name}
      </h2>
      <p className="mb-6 text-sm text-muted">{client.phone}</p>

      <div className="mb-3 flex items-center justify-between">
        <h3 className="font-display text-base font-semibold uppercase tracking-tight">
          Veículos
        </h3>
        <button
          onClick={() => setShowVehicleForm((v) => !v)}
          className="text-sm font-medium text-accent"
        >
          + Adicionar veículo
        </button>
      </div>

      {showVehicleForm && (
        <form
          onSubmit={handleAddVehicle}
          className="mb-5 grid grid-cols-2 gap-3 border border-line bg-surface p-4"
        >
          <input
            value={brand}
            onChange={(e) => setBrand(e.target.value)}
            placeholder="Marca"
            className="border border-line px-3 py-2 text-sm outline-none focus:border-accent"
            required
          />
          <input
            value={model}
            onChange={(e) => setModel(e.target.value)}
            placeholder="Modelo"
            className="border border-line px-3 py-2 text-sm outline-none focus:border-accent"
            required
          />
          <input
            value={year}
            onChange={(e) => setYear(e.target.value)}
            placeholder="Ano"
            className="border border-line px-3 py-2 text-sm outline-none focus:border-accent"
          />
          <input
            value={plate}
            onChange={(e) => setPlate(e.target.value)}
            placeholder="Placa"
            className="border border-line px-3 py-2 text-sm outline-none focus:border-accent"
          />
          <button
            type="submit"
            className="col-span-2 bg-ink py-2 text-sm font-medium text-canvas"
          >
            Salvar veículo
          </button>
        </form>
      )}

      <ul className="mb-8 divide-y divide-line border-y border-line">
        {vehicles.map((v) => (
          <li key={v.id} className="flex items-center justify-between py-3">
            <span>
              {v.brand} {v.model} {v.year ? `· ${v.year}` : ""}{" "}
              {v.plate ? `· ${v.plate}` : ""}
            </span>
            <button
              onClick={() => handleNewOrder(v.id)}
              className="border border-accent px-3 py-1 text-sm font-medium text-ink hover:bg-accent-soft"
            >
              Nova OS
            </button>
          </li>
        ))}
        {vehicles.length === 0 && (
          <p className="py-4 text-sm text-muted">Nenhum veículo cadastrado ainda.</p>
        )}
      </ul>

      <h3 className="mb-3 font-display text-base font-semibold uppercase tracking-tight">
        Ordens de serviço
      </h3>
      <ul className="divide-y divide-line border-y border-line">
        {orders.map((o) => {
          const vehicle = vehicles.find((v) => v.id === o.vehicle_id);
          return (
            <li key={o.id}>
              <Link
                to={`/ordens/${o.id}`}
                className="flex items-center justify-between py-3 hover:bg-surface"
              >
                <span>
                  {vehicle ? `${vehicle.brand} ${vehicle.model}` : "Veículo"} ·{" "}
                  {new Date(o.created_at).toLocaleDateString("pt-BR")}
                </span>
                <span className="text-sm text-muted">{statusLabel[o.status]}</span>
              </Link>
            </li>
          );
        })}
        {orders.length === 0 && (
          <p className="py-4 text-sm text-muted">Nenhuma ordem de serviço ainda.</p>
        )}
      </ul>
    </AppShell>
  );
}
