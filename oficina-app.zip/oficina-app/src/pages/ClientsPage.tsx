import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { AppShell } from "../components/AppShell";
import { supabase, Client } from "../lib/supabase";

export default function ClientsPage() {
  const [clients, setClients] = useState<Client[]>([]);
  const [search, setSearch] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [saving, setSaving] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    load();
  }, []);

  async function load() {
    const { data } = await supabase
      .from("clients")
      .select("*")
      .order("name");
    setClients((data as Client[]) ?? []);
  }

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    const { data } = await supabase
      .from("clients")
      .insert({ name, phone })
      .select()
      .single();
    setSaving(false);
    if (data) navigate(`/clientes/${data.id}`);
  }

  const filtered = clients.filter((c) =>
    c.name.toLowerCase().includes(search.toLowerCase()),
  );

  return (
    <AppShell>
      <div className="mb-5 flex items-center justify-between gap-3">
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Buscar cliente…"
          className="flex-1 border border-line bg-surface px-3 py-2 text-sm outline-none focus:border-accent"
        />
        <button
          onClick={() => setShowForm((v) => !v)}
          className="whitespace-nowrap bg-accent px-4 py-2 text-sm font-medium text-ink"
        >
          + Novo cliente
        </button>
      </div>

      {showForm && (
        <form
          onSubmit={handleCreate}
          className="mb-5 space-y-3 border border-line bg-surface p-4"
        >
          <div>
            <label className="mb-1 block text-sm font-medium">Nome</label>
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full border border-line px-3 py-2 text-sm outline-none focus:border-accent"
              required
            />
          </div>
          <div>
            <label className="mb-1 block text-sm font-medium">WhatsApp</label>
            <input
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="5511999990000"
              className="w-full border border-line px-3 py-2 text-sm outline-none focus:border-accent"
              required
            />
          </div>
          <button
            type="submit"
            disabled={saving}
            className="bg-ink px-4 py-2 text-sm font-medium text-canvas disabled:opacity-40"
          >
            {saving ? "Salvando…" : "Salvar e continuar"}
          </button>
        </form>
      )}

      <ul className="divide-y divide-line border-y border-line">
        {filtered.map((c) => (
          <li key={c.id}>
            <Link
              to={`/clientes/${c.id}`}
              className="flex items-center justify-between px-1 py-4 hover:bg-surface"
            >
              <span className="font-medium">{c.name}</span>
              <span className="text-sm text-muted">{c.phone}</span>
            </Link>
          </li>
        ))}
        {filtered.length === 0 && (
          <p className="py-6 text-sm text-muted">Nenhum cliente encontrado.</p>
        )}
      </ul>
    </AppShell>
  );
}
