import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { AppShell } from "../components/AppShell";
import { PhotoSection } from "../components/PhotoSection";
import {
  supabase,
  Client,
  Vehicle,
  ServiceOrder,
  ServiceItem,
  ServicePhoto,
  OrderStatus,
} from "../lib/supabase";
import { buildBudgetWhatsAppLink } from "../lib/whatsapp";

const statusOptions: { value: OrderStatus; label: string }[] = [
  { value: "aberta", label: "Aberta" },
  { value: "em_andamento", label: "Em andamento" },
  { value: "aguardando_aprovacao", label: "Aguardando aprovação" },
  { value: "aprovado", label: "Aprovado" },
  { value: "concluido", label: "Concluído" },
];

export default function ServiceOrderPage() {
  const { id } = useParams();

  const [order, setOrder] = useState<ServiceOrder | null>(null);
  const [client, setClient] = useState<Client | null>(null);
  const [vehicle, setVehicle] = useState<Vehicle | null>(null);
  const [items, setItems] = useState<ServiceItem[]>([]);
  const [photos, setPhotos] = useState<ServicePhoto[]>([]);

  const [description, setDescription] = useState("");
  const [itemDesc, setItemDesc] = useState("");
  const [itemValue, setItemValue] = useState("");

  useEffect(() => {
    if (id) load();
  }, [id]);

  async function load() {
    const { data: o } = await supabase
      .from("service_orders")
      .select("*")
      .eq("id", id)
      .single();
    if (!o) return;
    setOrder(o as ServiceOrder);
    setDescription(o.description ?? "");

    const [{ data: c }, { data: v }, { data: i }, { data: p }] =
      await Promise.all([
        supabase.from("clients").select("*").eq("id", o.client_id).single(),
        supabase.from("vehicles").select("*").eq("id", o.vehicle_id).single(),
        supabase
          .from("service_items")
          .select("*")
          .eq("service_order_id", id)
          .order("created_at"),
        supabase
          .from("service_photos")
          .select("*")
          .eq("service_order_id", id)
          .order("created_at"),
      ]);

    setClient(c as Client);
    setVehicle(v as Vehicle);
    setItems((i as ServiceItem[]) ?? []);
    setPhotos((p as ServicePhoto[]) ?? []);
  }

  async function saveDescription() {
    await supabase
      .from("service_orders")
      .update({ description, updated_at: new Date().toISOString() })
      .eq("id", id);
  }

  async function updateStatus(status: OrderStatus) {
    await supabase
      .from("service_orders")
      .update({ status, updated_at: new Date().toISOString() })
      .eq("id", id);
    load();
  }

  async function addItem(e: React.FormEvent) {
    e.preventDefault();
    if (!itemDesc || !itemValue) return;
    await supabase.from("service_items").insert({
      service_order_id: id,
      description: itemDesc,
      value: Number(itemValue.replace(",", ".")),
    });
    setItemDesc("");
    setItemValue("");
    load();
  }

  async function removeItem(itemId: string) {
    await supabase.from("service_items").delete().eq("id", itemId);
    load();
  }

  if (!order || !client || !vehicle) return null;

  const total = items.reduce((sum, i) => sum + Number(i.value), 0);
  const whatsappLink = buildBudgetWhatsAppLink({ client, vehicle, items });

  return (
    <AppShell>
      <Link
        to={`/clientes/${client.id}`}
        className="mb-4 inline-block text-sm text-muted hover:text-ink"
      >
        ← {client.name}
      </Link>

      <h2 className="font-display text-2xl font-semibold uppercase tracking-tight">
        {vehicle.brand} {vehicle.model}
      </h2>
      <p className="mb-5 text-sm text-muted">
        {vehicle.plate ? `Placa ${vehicle.plate}` : ""}{" "}
        {vehicle.year ? `· ${vehicle.year}` : ""}
      </p>

      <div className="mb-6">
        <label className="mb-1 block text-sm font-medium">Status</label>
        <select
          value={order.status}
          onChange={(e) => updateStatus(e.target.value as OrderStatus)}
          className="border border-line bg-surface px-3 py-2 text-sm outline-none focus:border-accent"
        >
          {statusOptions.map((s) => (
            <option key={s.value} value={s.value}>
              {s.label}
            </option>
          ))}
        </select>
      </div>

      <div className="mb-8">
        <label className="mb-1 block text-sm font-medium">
          Descrição do serviço
        </label>
        <textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          onBlur={saveDescription}
          rows={3}
          placeholder="O que precisa ser feito no veículo…"
          className="w-full border border-line bg-surface px-3 py-2 text-sm outline-none focus:border-accent"
        />
      </div>

      <div className="mb-8 space-y-6">
        <PhotoSection
          serviceOrderId={order.id}
          phase="antes"
          photos={photos.filter((p) => p.phase === "antes")}
          onUploaded={load}
        />
        <PhotoSection
          serviceOrderId={order.id}
          phase="depois"
          photos={photos.filter((p) => p.phase === "depois")}
          onUploaded={load}
        />
      </div>

      <div className="mb-6">
        <h3 className="mb-3 font-display text-base font-semibold uppercase tracking-tight">
          Orçamento
        </h3>

        <ul className="mb-3 divide-y divide-line border-y border-line">
          {items.map((i) => (
            <li key={i.id} className="flex items-center justify-between py-2">
              <span className="text-sm">{i.description}</span>
              <span className="flex items-center gap-3 text-sm">
                R$ {Number(i.value).toFixed(2)}
                <button
                  onClick={() => removeItem(i.id)}
                  className="text-cancel hover:underline"
                >
                  remover
                </button>
              </span>
            </li>
          ))}
          {items.length === 0 && (
            <p className="py-3 text-sm text-muted">
              Nenhum item no orçamento ainda.
            </p>
          )}
        </ul>

        <form onSubmit={addItem} className="mb-4 flex gap-2">
          <input
            value={itemDesc}
            onChange={(e) => setItemDesc(e.target.value)}
            placeholder="Peça ou serviço"
            className="flex-1 border border-line bg-surface px-3 py-2 text-sm outline-none focus:border-accent"
          />
          <input
            value={itemValue}
            onChange={(e) => setItemValue(e.target.value)}
            placeholder="Valor"
            inputMode="decimal"
            className="w-28 border border-line bg-surface px-3 py-2 text-sm outline-none focus:border-accent"
          />
          <button
            type="submit"
            className="bg-ink px-4 py-2 text-sm font-medium text-canvas"
          >
            Adicionar
          </button>
        </form>

        <div className="mb-4 flex items-center justify-between border-t border-line pt-3">
          <span className="font-display text-base font-semibold uppercase tracking-tight">
            Total
          </span>
          <span className="font-display text-lg font-semibold">
            R$ {total.toFixed(2)}
          </span>
        </div>

        <a
          href={whatsappLink}
          target="_blank"
          rel="noreferrer"
          className={`block w-full py-3 text-center font-medium ${
            items.length === 0
              ? "pointer-events-none bg-line text-muted"
              : "bg-accent text-ink"
          }`}
        >
          Enviar orçamento pelo WhatsApp
        </a>
        <p className="mt-2 text-xs text-muted">
          Abre o WhatsApp de {client.name} com a lista de itens e o total já
          escritos na mensagem.
        </p>
      </div>
    </AppShell>
  );
}
