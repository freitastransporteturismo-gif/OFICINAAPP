import { Link } from "react-router-dom";
import { supabase } from "../lib/supabase";

export function AppShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-canvas">
      <header className="border-b border-line bg-surface px-5 py-4">
        <div className="mx-auto flex max-w-3xl items-center justify-between">
          <Link to="/">
            <p className="text-sm text-accent">🔧 Oficina</p>
            <h1 className="font-display text-lg font-semibold uppercase tracking-tight">
              Ordens de serviço
            </h1>
          </Link>
          <button
            onClick={() => supabase.auth.signOut()}
            className="text-sm text-muted hover:text-ink"
          >
            Sair
          </button>
        </div>
      </header>

      <main className="mx-auto max-w-3xl px-5 py-6">{children}</main>
    </div>
  );
}
