import { useRef, useState } from "react";
import { supabase, ServicePhoto } from "../lib/supabase";

export function PhotoSection({
  serviceOrderId,
  phase,
  photos,
  onUploaded,
}: {
  serviceOrderId: string;
  phase: "antes" | "depois";
  photos: ServicePhoto[];
  onUploaded: () => void;
}) {
  const [uploading, setUploading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  async function handleFiles(files: FileList | null) {
    if (!files || files.length === 0) return;
    setUploading(true);

    for (const file of Array.from(files)) {
      const path = `${serviceOrderId}/${phase}/${crypto.randomUUID()}-${file.name}`;
      const { error } = await supabase.storage
        .from("fotos-os")
        .upload(path, file);

      if (!error) {
        const { data } = supabase.storage.from("fotos-os").getPublicUrl(path);
        await supabase.from("service_photos").insert({
          service_order_id: serviceOrderId,
          url: data.publicUrl,
          phase,
        });
      }
    }

    setUploading(false);
    onUploaded();
    if (inputRef.current) inputRef.current.value = "";
  }

  return (
    <div>
      <div className="mb-2 flex items-center justify-between">
        <h4 className="font-display text-sm font-semibold uppercase tracking-tight">
          {phase === "antes" ? "Fotos de antes" : "Fotos de depois"}
        </h4>
        <label className="cursor-pointer text-sm font-medium text-accent">
          {uploading ? "Enviando…" : "+ Adicionar foto"}
          <input
            ref={inputRef}
            type="file"
            accept="image/*"
            capture="environment"
            multiple
            className="hidden"
            onChange={(e) => handleFiles(e.target.files)}
          />
        </label>
      </div>

      {photos.length === 0 ? (
        <p className="text-sm text-muted">Nenhuma foto ainda.</p>
      ) : (
        <div className="grid grid-cols-3 gap-2">
          {photos.map((p) => (
            <img
              key={p.id}
              src={p.url}
              alt={phase}
              className="aspect-square w-full border border-line object-cover"
            />
          ))}
        </div>
      )}
    </div>
  );
}
