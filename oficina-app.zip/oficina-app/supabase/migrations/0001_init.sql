-- Clientes da oficina
create table if not exists public.clients (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  phone text not null,  -- WhatsApp do cliente, formato 55DDDNÚMERO (só dígitos)
  created_at timestamptz not null default now()
);

-- Veículos (um cliente pode ter mais de um)
create table if not exists public.vehicles (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.clients(id) on delete cascade,
  brand text not null,
  model text not null,
  year text,
  plate text,
  created_at timestamptz not null default now()
);

-- Ordens de serviço
create table if not exists public.service_orders (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.clients(id) on delete cascade,
  vehicle_id uuid not null references public.vehicles(id) on delete cascade,
  description text not null default '',
  status text not null default 'aberta'
    check (status in ('aberta', 'em_andamento', 'aguardando_aprovacao', 'aprovado', 'concluido')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Itens do orçamento (peças e serviços)
create table if not exists public.service_items (
  id uuid primary key default gen_random_uuid(),
  service_order_id uuid not null references public.service_orders(id) on delete cascade,
  description text not null,
  value numeric(10, 2) not null default 0,
  created_at timestamptz not null default now()
);

-- Fotos de antes/depois
create table if not exists public.service_photos (
  id uuid primary key default gen_random_uuid(),
  service_order_id uuid not null references public.service_orders(id) on delete cascade,
  url text not null,
  phase text not null check (phase in ('antes', 'depois')),
  created_at timestamptz not null default now()
);

create index if not exists idx_vehicles_client on public.vehicles(client_id);
create index if not exists idx_orders_client on public.service_orders(client_id);
create index if not exists idx_orders_vehicle on public.service_orders(vehicle_id);
create index if not exists idx_items_order on public.service_items(service_order_id);
create index if not exists idx_photos_order on public.service_photos(service_order_id);

-- RLS: sistema interno de uma conta só — tudo exige login.
alter table public.clients enable row level security;
alter table public.vehicles enable row level security;
alter table public.service_orders enable row level security;
alter table public.service_items enable row level security;
alter table public.service_photos enable row level security;

create policy "Somente autenticado - clients" on public.clients
  for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

create policy "Somente autenticado - vehicles" on public.vehicles
  for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

create policy "Somente autenticado - service_orders" on public.service_orders
  for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

create policy "Somente autenticado - service_items" on public.service_items
  for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

create policy "Somente autenticado - service_photos" on public.service_photos
  for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

-- Storage: bucket para as fotos de antes/depois
insert into storage.buckets (id, name, public)
values ('fotos-os', 'fotos-os', true)
on conflict (id) do nothing;

create policy "Autenticado envia fotos" on storage.objects
  for insert with check (bucket_id = 'fotos-os' and auth.role() = 'authenticated');

create policy "Qualquer um vê as fotos (link direto)" on storage.objects
  for select using (bucket_id = 'fotos-os');

create policy "Autenticado apaga fotos" on storage.objects
  for delete using (bucket_id = 'fotos-os' and auth.role() = 'authenticated');
